from django.db import models
import datetime
from django.contrib.auth.models import User

# Create your models here.

class Status(models.Model):
    account_number = models.IntegerField()
    invested = models.IntegerField()
    balance = models.IntegerField()
    user_name = models.CharField(max_length = 150, default = None)


class Contactform(models.Model):
    name = models.CharField(max_length= 100)
    email = models.EmailField(unique= True)
    subject = models.CharField(max_length= 100)
    message = models.CharField(max_length= 900)
    image = models.ImageField(upload_to= "images/")


class Referral(models.Model):
	user = models.OneToOneField(User, on_delete= models.CASCADE, blank= True, null= True)
	link = models.CharField(max_length= 40)
    
	
	def _str_(self):
		return self.link
		
		
class ReferralNotification(models.Model):
	user = models.ForeignKey(User, on_delete= models.CASCADE, blank= True, null= True)
	message = models.CharField(max_length= 200)
	
	def _str_(self):
		return self.message    

    
	
    
    
	
	

