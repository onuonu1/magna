from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.models import User, auth
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from .models import Referral, Status, ReferralNotification
from .models import Contactform
from .import models
import random



# Create your views here.

def randomGen():
    # return a 6 digit random number
    return int(random.uniform(100000, 999999))
   
def index(request):
       

    if request.method == "POST":
        name = request.POST.get('name')
        email = request.POST.get('email')
        subject = request.POST.get('subject')
        message = request.POST.get('message')
        image = request.FILES['attachment']
       
        print(request.FILES)
        print(name, email, subject, message, image) 
        Contactform.objects.create(name=name, email=email, subject=subject, message=message, image=image)       
        
    
        curr_user = Status.objects.get(user_name=request.user) # getting details of current user
    
        # if no details exist (new user), create new details
        curr_user = Status()
        curr_user.account_number = randomGen() # random account number for every new user
        curr_user.balance = 0
        curr_user.invested = 0
        curr_user.user_name = request.user
        curr_user.save()        
    return render(request, "index.html")


def register(request):

    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')
        password2 = request.POST.get('password2')
        country = request.POST.get('country')


        if password==password2:       
            if User.objects.filter(email=email).exists():
                messages.info(request, 'Email Taken')
                return redirect('register')
            elif User.objects.filter(username=username).exists():
                messages.info(request, 'Username Taken')
                return redirect('register')
            else:
                user = User.objects.create_user(username=username, email=email, password=password,)
                user.save()
                messages.success(request, "Thank you for registering, We awaits your investment!!!")
                return redirect('login')

        else:
            messages.info(request, 'Password Not Matching')
            return redirect('register')
    
    else:
        return render(request,'register.html') 

def login(request):

    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        user = auth.authenticate(username=username, password=password)

        if user is not None:
            auth.login(request, user)
            return redirect('/')
        else:
            messages.info(request, 'Invalid Credentials')
            return redirect('login')

    else:
        return render(request, 'login.html')

def logout(request):
    auth.logout(request)
    return redirect('/')

def innerpage(request):

    return render(request,'innerpage.html') 


def on_click_referral_link(request, ref_link):
	page = "referral"
	link = get_object_or_404(Referral, link= ref_link)
    
	
	if request.method == 'POST':
		username = request.POST.get('username')
		email = request.POST.get('email')
		password = request.POST.get('password')
		password2 = request.POST.get('password2')
		link_from_html = request.POST.get("ref_link")

		if password==password2:
			if User.objects.filter(email=email).exists():
				messages.info(request, 'Email Taken')
				return redirect("ref", ref_link= ref_link)
				
			elif User.objects.filter(username=username).exists():
				messages.info(request, 'Username Taken')
				return redirect("ref", ref_link= ref_link)
				
			elif not Referral.objects.filter(link= link_from_html).exists():
				messages.error(request, "Invalid Referral Code")
				return redirect("ref", ref_link= ref_link)
				
			else:
				user = User.objects.create_user(
					username= username,
					email=email,
					password=password,
				)
				
				code_owner = Referral.objects.get(link= link_from_html).user
                
				
				ReferralNotification.objects.create(
					user= code_owner,
					message= f"{user} registered with your referral code"
				)
				
				user.save()
				return redirect('login')
	
		else:
			messages.info(request, 'Password Not Matching')
			return redirect("ref", ref_link= ref_link)
	
	context = {"ref_link": ref_link, "page": page}
    
	return render(request, "register.html", context)     


