from django.db.models.signals import post_save
from django.contrib.auth.models import User
from .models import *
import random


def customer_referral_link(sender, instance, created, **kwargs):
	if created:
		# create referral link for user
		string = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890&$#@?"
		link = "".join(random.choices(string, k= 10))
		referral_link = Referral.objects.create(
			user= instance,
			link= link
		)
		referral_link.save()
		print("Created")
		
		
post_save.connect(customer_referral_link, sender= User)